/* 🛑 ORGANIZATION PLAN FOR THIS CHAOS 🛑 */
/* Telling our future selves where stuff is stacked: 
   - Variables first
   - Functions second
   - Actual UI rendering last (the sexy stuff)
*/
import './App.css'; // Import our badass styling that we roasted earlier
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import HomePage from './HomePage';
import LibrariesPage from './LibrariesPage';
import BookshelfPage from './BookshelfPage';
import DnfPage from './DnfPage';
import YearlyWrapupPage from './YearlyWrapUpPage';

function App() {
  return (
    <Router>
      <div
        className="app-wrapper"
        style={{
          width: '100%',
          boxSizing: 'border-box'
        }}
      >
        <nav className="main-nav">
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/libraries">My Libraries</Link></li>
            <li><Link to="/bookshelf">My Bookshelf</Link></li>
            <li><Link to="/yearly-wrapup">My Yearly Wrapup</Link></li>
            <li><Link to="/dnf">DNF</Link></li>
          </ul>
        </nav>

        <div className="page-banner">
          <h1 className="page-banner-text">Page Turning & Soul Burning</h1>
        </div>

        <div
          className="background"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
              url(${import.meta.env.BASE_URL}newbg.png)
            `,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundAttachment: 'fixed',
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            width: '100%',
            height: '100%',
            zIndex: -2
          }}
        ></div>

        <div className="app-container">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/libraries" element={<LibrariesPage />} />
            <Route path="/bookshelf" element={<BookshelfPage />} />
            <Route path="/yearly-wrapup" element={<YearlyWrapupPage />} />
            <Route path="/dnf" element={<DnfPage />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;