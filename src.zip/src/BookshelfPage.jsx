

import React from 'react';

const BookshelfPage = () => {
  return (
    <div className="bookshelf-page">
      <div className="bookshelf-header">
        <h1>🪶 My Bookshelf</h1>
        <p>A cozy corner of stories, secrets, and whispered dreams...</p>
      </div>
      <div className="bookshelf-empty">
        <p>🌙 Your bookshelf is waiting to be filled.</p>
        <p>Add your favorite tales to weave your own legend!</p>
      </div>
    </div>
  );
};

export default BookshelfPage;