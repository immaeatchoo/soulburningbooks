import React, { useState, useEffect } from 'react';
import Modal from './components/Modal';

const LibrariesPage = () => {
  const [books, setBooks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    series: '',
    book_number: '',
    rating: 0,
    date_read: '',
    cover: null,
  });
  const [sortOption, setSortOption] = useState('date_read');

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await fetch('/api/books');
      const data = await response.json();
      setBooks(data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewBook((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddBook = async () => {
    try {
      const formData = new FormData();
      Object.entries(newBook).forEach(([key, value]) => {
        formData.append(key, value);
      });

      await fetch('/api/books', {
        method: 'POST',
        body: formData,
      });

      fetchBooks();
      setShowModal(false);
    } catch (error) {
      console.error('Error adding book:', error);
    }
  };

  const handleDeleteBook = async (id) => {
    try {
      await fetch(`/api/books/${id}`, {
        method: 'DELETE',
      });

      fetchBooks();
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  const handleSortChange = (e) => {
    setSortOption(e.target.value);
  };

  const sortedBooks = [...books].sort((a, b) => {
    if (sortOption === 'date_read') {
      return new Date(b.date_read) - new Date(a.date_read);
    }
    if (sortOption === 'title') {
      return a.title.localeCompare(b.title);
    }
    if (sortOption === 'author') {
      return a.author.localeCompare(b.author);
    }
    return 0;
  });

  return (
    <div className="libraries-page">
      <div className="sort-options">
        <label htmlFor="sort-select">Sort By:</label>
        <select id="sort-select" value={sortOption} onChange={handleSortChange}>
          <option value="date_read">Date Read</option>
          <option value="title">Title</option>
          <option value="author">Author</option>
        </select>
      </div>
      <button className="open-modal-button" onClick={() => setShowModal(true)}>Add New Book</button>

      {showModal && (
        <Modal onClose={() => setShowModal(false)}>
          <form className="add-book-form" onSubmit={(e) => {
            e.preventDefault();
            handleAddBook();
          }}>
            <input name="title" value={newBook.title} onChange={handleInputChange} placeholder="Title" required />
            <input name="author" value={newBook.author} onChange={handleInputChange} placeholder="Author" required />
            <input name="series" value={newBook.series} onChange={handleInputChange} placeholder="Series" />
            <input name="book_number" value={newBook.book_number} onChange={handleInputChange} placeholder="Book #" />
            <input name="date_read" type="date" value={newBook.date_read} onChange={handleInputChange} />
            <button type="submit">Save Book</button>
          </form>
        </Modal>
      )}

      <div className="book-grid">
        {sortedBooks.map((book) => (
          <div key={book.id} className="book-card">
            {book.cover && <img src={book.cover} alt={book.title} />}
            <h2>{book.title}</h2>
            <p className="author-name">{book.author}</p>
            <p className="date-read">{book.date_read}</p>
            {book.series && (
              <p className="series-info">
                {book.series} {book.book_number && `#${book.book_number}`}
              </p>
            )}
            <div className="star-rating">
              {[1, 2, 3, 4, 5].map((star) => (
                <button key={star} className={`star ${book.rating >= star ? 'selected' : ''}`} disabled>★</button>
              ))}
            </div>
            <button className="delete-button" onClick={() => handleDeleteBook(book.id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LibrariesPage;
