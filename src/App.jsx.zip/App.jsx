import { useEffect, useState } from 'react'; // Grab magic React powers to control state and side effects
import debounce from 'lodash.debounce';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import HomePage from './HomePage';
import BookshelfPage from './BookshelfPage';
import YearlyWrapUpPage from './YearlyWrapUpPage';
import DnfPage from './DnfPage';
import './App.css'; // Import our badass styling that we roasted earlier

// --------------------------
// 📚 STATE VARIABLES: Tracking All The Shit We Care About
// --------------------------

/* 🛑 ORGANIZATION PLAN FOR THIS CHAOS 🛑 */
/* Telling our future selves where stuff is stacked: 
   - Variables first
   - Functions second
   - Actual UI rendering last (the sexy stuff)
*/


function App() {
  // --------------------------
  // 🖼️ COVER REVIEW STATE VARIABLES
  // --------------------------
  const [pendingCoverFixes, setPendingCoverFixes] = useState([]);
  const [currentCoverSearchResults, setCurrentCoverSearchResults] = useState({});
  const [isReviewingCovers, setIsReviewingCovers] = useState(false);
  // Cover Review batching
  const [reviewBatchSize, setReviewBatchSize] = useState(20);
  // Loading state for fetching covers
  const [isFetchingCovers, setIsFetchingCovers] = useState(false);
  // 📚 STATE VARIABLES: Tracking All The Shit We Care About
  // --------------------------

  /* List of all books we fetched from the server (empty squad at first) */
  const [books, setBooks] = useState([]);

  /* New book form fields (blank book ready for love) */
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    series: '',
    book_number: '',
    date_read: '',
    rating: 0,
  });

  /* Hover magic for the stars in the review (so they light up when you mouse over) */
  const [hoverRating, setHoverRating] = useState(0);

  /* Dropdown list of all known series names (starting with just "Standalone" for the lone wolves) */
  const [seriesOptions, setSeriesOptions] = useState(['Standalone']);
  // Track the original series options for rename mapping in Series Manager
  const [originalSeriesOptions, setOriginalSeriesOptions] = useState([]);

  /* When you type a brand new series name (not picking from the dropdown) */
  const [newSeriesName, setNewSeriesName] = useState('');

  // --------------------------
  // 🎭 MODAL CONTROL VARIABLES: Opening, Closing, Editing
  // --------------------------

  /* What field to sort books by — title/author/series (default is title) */
  const [sortOption, setSortOption] = useState('title');

  /* ID of the book we're editing right now (null = nobody's being edited) */
  const [editId, setEditId] = useState(null);

  /* The book we're live-editing inside the grid (only matters when inline editing) */
  const [inlineEditBook, setInlineEditBook] = useState(null);

  /* Whether the Add/Edit Book Modal is open or not */
  const [showModal, setShowModal] = useState(false);

  // Pagination State for Book Grid 
  const [currentPage, setCurrentPage] = useState(1);
  const booksPerPage = 16; // Number of books to show per page

  // Settings and Series Manager modals
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showSeriesManager, setShowSeriesManager] = useState(false);
  // State for Goodreads CSV import spinner
  const [isImporting, setIsImporting] = useState(false);
  // --------------------------
  // 🔥 FETCH ALL BOOKS RIGHT WHEN PAGE LOADS
  // --------------------------
  useEffect(() => {
    fetchBooks(); // As soon as this page wakes up, go grab the books from the backend
  }, []);

  // 🕵️‍♀️ fetchBooks: Go beg the backend for the latest book list and update our state.
  const fetchBooks = () => {
    fetch('http://localhost:5001/api/books') // Go knock on the backend's door and ask for books
      .then((res) => res.json()) // Take the backend's mumbling and turn it into something readable (JSON)
      .then((data) => {
        setBooks(data || []); // Update our book collection (or, if the backend is empty, just vibe with an empty list)

        // Build a Set (the "no duplicates allowed" club) to hold all unique series names
        const seriesSet = new Set(['Standalone']); // "Standalone" always gets an invite, even if nobody else shows up

        (data || []).forEach((book) => {
          if (book.series) seriesSet.add(book.series); // If the book has a series, toss it in the club
        });

        setSeriesOptions(Array.from(seriesSet)); // Turn the Set back into an array, because React is picky like that
        setOriginalSeriesOptions(Array.from(seriesSet)); // Keep a copy of the original series list for rename mapping
      })
      .catch((err) => console.error("Failed to fetch books:", err)); // If the backend faceplants, log the drama
  };

  // Import books marked as "read" from Goodreads CSV with confirmation
  const importGoodreadsCSV = async (file) => {
    setIsImporting(true);
    setReviewBatchSize(20);
    console.log("📥 Starting Goodreads CSV import...");
    const reader = new FileReader();
    reader.onload = async (e) => {
      console.log("📑 CSV file loaded, parsing...");
      const text = e.target.result;
      const lines = text.split('\n');
      const headers = lines[0].split(',');

      const titleIndex = headers.findIndex(h => h.toLowerCase().includes("title"));
      const authorIndex = headers.findIndex(h => h.toLowerCase().includes("author"));
      const dateReadIndex = headers.findIndex(h => h.toLowerCase().includes("date read"));
      const isbnIndex = headers.findIndex(h => h.toLowerCase().includes("isbn"));
      const ratingIndex = headers.findIndex(h => h.toLowerCase().includes("my rating"));

      const currentTitles = new Set(books.map(book => `${book.title.toLowerCase()}-${book.author.toLowerCase()}`));

      const readBooks = lines.slice(1).map(line => {
        const cells = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/); // CSV-safe split
        const dateRead = cells[dateReadIndex]?.replace(/^"|"$/g, '').trim();
        if (!dateRead) return null; // Only books with Date Read

        let title = cells[titleIndex]?.replace(/^"|"$/g, '').trim();
        const author = cells[authorIndex]?.replace(/^"|"$/g, '').trim();
        const key = `${title.toLowerCase()}-${author.toLowerCase()}`;
        if (currentTitles.has(key)) return null; // Skip duplicate

        let series = 'Standalone';
        let book_number = '';

        // Check if the title includes series info, like "Title (Series, #1)"
        const seriesMatch = title.match(/^(.*?)\s*\((.*?),\s*#(\d+)\)$/);
        if (seriesMatch) {
          title = seriesMatch[1].trim();
          series = seriesMatch[2].trim();
          book_number = seriesMatch[3].trim();
        }

        return {
          title,
          author,
          date_read: dateRead,
          rating: parseInt(cells[ratingIndex]?.trim()) || 0,
          isbn: cells[isbnIndex]?.replace(/^"|"$/g, '').trim() || '',
          series,
          book_number
        };
      }).filter(Boolean);

      let importedCount = 0;
      console.log(`📚 Found ${readBooks.length} books to import.`);

      for (const book of readBooks) {
        console.log("📘 Importing:", book.title);

        // Always fetch Google Books data for each imported book
        try {
          console.log("🔎 Fetching Google Books cover for:", book.title, "by", book.author);
          const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=intitle:${encodeURIComponent(book.title)}+inauthor:${encodeURIComponent(book.author)}&key=AIzaSyDa3w8LgZWx27xz8qyK3uTnt9BRKNUmZlg`);
          const data = await response.json();
          if (data.items?.length) {
            const info = data.items[0].volumeInfo;
            if (info.imageLinks?.thumbnail) {
              book.cover = info.imageLinks.thumbnail;
              console.log("✅ Cover fetched for:", book.title);
            }
          }
        } catch (err) {
          console.warn("❌ Cover fetch failed for:", book.title, err);
        }

        // Add series to options if new
        if (book.series && !seriesOptions.includes(book.series)) {
          setSeriesOptions(prev => [...new Set([...prev, book.series])]);
        }

        console.log("📤 Sending to backend:", book.title);
        try {
          const response = await fetch('http://localhost:5001/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...book,
              series: book.series || 'Standalone',
              book_number: book.book_number || '',
              cover: book.cover || ''
            }),
          });

          if (response.ok) {
            console.log("✅ Book added:", book.title);
            importedCount++;
          } else {
            console.error("❌ Failed to add:", book.title);
          }
        } catch (err) {
          console.error("❌ Error during POST for:", book.title, err);
        }
      }

      fetchBooks(); // Refresh grid after import

      // Show confirmation
      setTimeout(() => {
        if (importedCount > 0) {
          alert(`✅ Import complete! ${importedCount} new book(s) added.`);
        } else {
          alert(`⚠️ No new books were imported. They already exist.`);
        }
        setIsImporting(false);
        // Cover Review Mode: review covers after import
        setReviewBatchSize(20);
        setPendingCoverFixes(readBooks);
        setIsReviewingCovers(true);
        fetchNewCovers(readBooks[0]);
      }, 500);
    }; // <-- close reader.onload
    reader.readAsText(file);
  };

  // --------------------------
  // 🖼️ COVER REVIEW MODE HELPERS (Refactored for All-at-Once Review)
  // --------------------------
  const fetchNewCovers = async (book) => {
    const bookKey = `${book.title.toLowerCase()}-${book.author.toLowerCase()}`;
    setIsFetchingCovers(true);

    // If book has no cover yet, try to fetch one using Google Books API
    if (!book.cover) {
      try {
        const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=intitle:${encodeURIComponent(book.title)}+inauthor:${encodeURIComponent(book.author)}&key=AIzaSyDa3w8LgZWx27xz8qyK3uTnt9BRKNUmZlg`);
        const data = await response.json();
        if (data.items?.length) {
          const first = data.items[0].volumeInfo;
          if (first.imageLinks?.thumbnail) {
            book.cover = first.imageLinks.thumbnail;
            try {
              await fetch(`http://localhost:5001/books/${book.id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ cover: book.cover })
              });
              console.log("✅ Book cover saved to backend:", book.title);
            } catch (err) {
              console.warn("⚠️ Failed to save cover to backend:", book.title, err);
            }
          }
        }
      } catch (err) {
        console.warn("❌ Cover fetch failed for:", book.title, err);
      }
    }

    const tryFetch = async (query) => {
      const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${query}&key=AIzaSyDa3w8LgZWx27xz8qyK3uTnt9BRKNUmZlg`);
      const data = await response.json();
      const covers = [];

      if (data.items?.length) {
        data.items.forEach(item => {
          if (item.volumeInfo?.imageLinks?.thumbnail) {
            covers.push(item.volumeInfo.imageLinks.thumbnail);
          }
        });
      }
      return covers;
    };

    try {
      let covers = await tryFetch(`intitle:${encodeURIComponent(book.title)}+inauthor:${encodeURIComponent(book.author)}`);
      if (covers.length === 0) {
        covers = await tryFetch(`intitle:${encodeURIComponent(book.title)}`);
      }

      setCurrentCoverSearchResults(prev => ({
        ...prev,
        [bookKey]: covers
      }));
    } catch (err) {
      console.error('Failed to fetch new covers:', err);
    }

    setIsFetchingCovers(false);
  };

  const selectNewCover = async (book, newCoverUrl) => {
    book.cover = newCoverUrl;
    if (book.id) {
      await fetch(`http://localhost:5001/books/${book.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cover: newCoverUrl }),
      });
    }
    removeBookFromPending(book);
  };

  const keepCurrentCover = (book) => {
    removeBookFromPending(book);
  };

  const skipBook = (book) => {
    removeBookFromPending(book);
  };

  const refetchCovers = (book) => {
    fetchNewCovers(book);
  };

  const removeBookFromPending = (book) => {
    const updatedList = pendingCoverFixes.filter(
      (b) => b.title.toLowerCase() !== book.title.toLowerCase() || b.author.toLowerCase() !== book.author.toLowerCase()
    );
    setPendingCoverFixes(updatedList);
    // If the remaining books are less than current batch, expand batch
    if (updatedList.length < reviewBatchSize && updatedList.length > 0) {
      setReviewBatchSize(prev => Math.min(prev + 1, updatedList.length));
    }
    if (updatedList.length === 0) {
      setIsReviewingCovers(false);
      fetchBooks();
    }
  };

  // Add state for search results and dropdown
  const [searchResults, setSearchResults] = useState([]);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  // Smart search using Google Books API (debounced)
  const searchGoogleBooks = debounce(async (query) => {
    if (!query.trim() || query.trim().length < 4) {
      setSearchResults([]);
      return;
    }
    try {
      const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}&key=AIzaSyDa3w8LgZWx27xz8qyK3uTnt9BRKNUmZlg`);
      const data = await response.json();
      if (data.items) {
        const results = data.items.map(item => {
          const info = item.volumeInfo;
          let series = 'Standalone';
          let book_number = '';

          // Prefer info.seriesInfo if available
          if (info.seriesInfo && info.seriesInfo.series) {
            series = info.seriesInfo.series;
            if (info.seriesInfo.bookDisplayNumber) {
              book_number = info.seriesInfo.bookDisplayNumber;
            }
          } else if (info.title && /a court of|book|volume|part/i.test(info.title)) {
            // Try to parse from title: e.g. "Throne of Glass #2", "A Court of Thorns and Roses: Book 1"
            // Try to extract the number after # or Book/Volume/Part
            let numberMatch = info.title.match(/#\s?(\d+)|book\s*(\d+)|volume\s*(\d+)|part\s*(\d+)/i);
            if (numberMatch) {
              book_number = numberMatch[1] || numberMatch[2] || numberMatch[3] || numberMatch[4] || '';
            }
            // Try to extract series as everything before #/Book/Volume/Part/:
            let seriesMatch = info.title.match(/^(.*?)(?:\s*[:-]\s*)?(?:book|volume|part)?\s*#?\d*/i);
            if (seriesMatch && seriesMatch[1]) {
              // Avoid using the title as series if it's a standalone
              const s = seriesMatch[1].trim();
              if (s && !/^standalone$/i.test(s)) {
                series = s;
              }
            }
          } else if (info.subtitle && /book|volume|part/i.test(info.subtitle)) {
            // Use subtitle for series if it matches
            let subMatch = info.subtitle.match(/^(.*?)(?:book|volume|part)?\s*#?\d*/i);
            if (subMatch && subMatch[1]) {
              const s = subMatch[1].trim();
              if (s && !/^standalone$/i.test(s)) {
                series = s;
              }
            }
          }

          return {
            title: info.title || '',
            author: info.authors?.[0] || '',
            cover: info.imageLinks?.thumbnail || null,
            series,
            book_number
          };
        });
        // Filter for close title match before slicing top 5
        const lowerQuery = query.toLowerCase();
        const filteredResults = results.filter(book =>
          book.title.toLowerCase().includes(lowerQuery) ||
          book.series?.toLowerCase().includes(lowerQuery) ||
          book.author?.toLowerCase().includes(lowerQuery)
        );
        setSearchResults(filteredResults.slice(0, 10));
        setShowSearchDropdown(true);
      }
    } catch (err) {
      console.error('Google Books search failed:', err);
      setSearchResults([]);
    }
  }, 400);

  // handleChange: Whenever the user types in a form field, update the newBook object accordingly
  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewBook((prev) => ({ ...prev, [name]: value }));

    if (name === 'title') {
      searchGoogleBooks(value);
    }
  };

  // handleStarClick: When a user thirstily clicks a star, set the rating for the new book
  const handleStarClick = (rating) => {
    setNewBook((prevBook) => ({
      ...prevBook,
      rating, // Set the rating to whatever number of stars they clicked
    }));
  };


  // deleteBook: Ask the user if they're sure, then send the book to the shadow realm (delete from backend)
  const deleteBook = (id) => {
    if (window.confirm("Are you sure you want to send this book into the abyss 🔥?")) {
      fetch(`http://localhost:5001/books/${id}`, { method: 'DELETE' }) // Tell the backend to nuke this book
        .then(() => fetchBooks()); // Refresh the book list so the ghost is gone
    }
  };

  // startEdit: User clicked the ✏️, so we're about to let them mess with this book's info inline
  const startEdit = (book) => {
    fetchBooks(); // Refresh books to ensure latest series list is reflected in inline editing
    setEditId(book.id); // Mark this book as "currently being edited"
    setInlineEditBook({ ...book }); // Make a copy so we can edit without immediately trashing the original
  };

  // handleSubmit: When the form is submitted (add/update book), do all the backend drama and reset the UI
  const handleSubmit = (e) => {
    e.preventDefault(); // Don't let the browser try to reload the page like it's 1999

    const finalBook = { ...newBook }; // Make a copy of the book we're about to send
    if (newBook.series === '__new') {
      finalBook.series = newSeriesName.trim(); // If they added a new series, use that name instead of the magic placeholder
    }

    if (editId) {
      // If we're editing, PATCH the existing book
      fetch(`http://localhost:5001/books/${editId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalBook),
      })
        .then((res) => {
          if (!res.ok) throw new Error("Failed to update book"); // Complain if the backend is rude
          return res.json();
        })
        .then(() => {
          fetchBooks(); // Refresh the list so the changes show up
          setNewBook({
            title: '',
            author: '',
            series: '',
            book_number: '',
            date_read: '',
            rating: 0,
          }); // Reset the form fields so they're fresh for the next book
          setNewSeriesName(''); // Clear the new series input
          setEditId(null); // No longer editing anyone
          setShowModal(false); // Close the modal, we're done here
        })
        .catch((err) => console.error(err));
    } else {
      // If we're adding a new book, POST it to the backend
      fetch('http://localhost:5001/api/books', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalBook),
      })
        .then((res) => {
          if (!res.ok) throw new Error("Failed to add book"); // If the backend is being a diva, throw a fit
          return res.json();
        })
        .then(() => {
          fetchBooks(); // Refresh the book list so our new baby shows up
          setNewBook({
            title: '',
            author: '',
            series: '',
            book_number: '',
            date_read: '',
            rating: 0,
          }); // Reset the form for next time
          setNewSeriesName(''); // Clear any new series input
          setShowModal(false); // Close the modal and let the user bask in their accomplishment
        })
        .catch((err) => console.error(err));
    }
  };

  /* Sort the books array by the selected sortOption */
  const sortedBooks = [...books].sort((a, b) => {
    const fieldA = (a[sortOption] || '').toString().toLowerCase();
    const fieldB = (b[sortOption] || '').toString().toLowerCase();
    return fieldA.localeCompare(fieldB);
  });

  // Pagination logic
  // Calculate books to display based on current page
  const indexOfLastBook = currentPage * booksPerPage;
  const indexOfFirstBook = indexOfLastBook - booksPerPage;
  const currentBooks = sortedBooks.slice(indexOfFirstBook, indexOfLastBook);
// Calculate total pages
  const totalPages = Math.ceil(sortedBooks.length / booksPerPage);
  // Handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  // saveInline: User clicked "Save" in the inline edit form, so PATCH the backend and clean up our mess
  const saveInline = () => {
    fetch(`http://localhost:5001/books/${editId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(inlineEditBook),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to update book"); // If backend refuses, whine in the console
        return res.json();
      })
      .then(() => {
        fetchBooks(); // Refresh the book list so our edits are visible
        setEditId(null); // Nobody is being edited anymore
        setInlineEditBook(null); // Clear out the inline edit state so we don't keep ghosts around
      })
      .catch((err) => console.error(err));
  };

  // --------------------------
  // 🖼️ COVER REVIEW MODE RENDER (Batch mode)
  // --------------------------
  if (isReviewingCovers) {
    return (
      <div className="cover-review-wrapper" style={{ position: 'relative' }}>
        <h1>🖼️ Review Your Book Covers</h1>
        <button
          onClick={() => setIsReviewingCovers(false)}
          title="Exit Cover Review"
          style={{
            position: 'absolute',
            top: '2rem',
            right: '2rem',
            background: 'none',
            border: 'none',
            fontSize: '1.5rem',
            color: '#ccc',
            cursor: 'pointer',
            zIndex: 10
          }}
        >
          ✖
        </button>

        {pendingCoverFixes.slice(0, reviewBatchSize).map((book) => {
          const bookKey = `${book.title.toLowerCase()}-${book.author.toLowerCase()}`;
          const covers = currentCoverSearchResults[bookKey] || [];

          return (
            <div className="cover-review-card" key={bookKey} style={{ marginBottom: '2rem' }}>
              <h2>{book.title} by {book.author}</h2>

              <div className="current-cover">
                <h3>Current Cover</h3>
                {book.cover ? (
                  <img src={book.cover} alt="Current Cover" className="cover-img" />
                ) : (
                  <div className="no-cover-placeholder">No cover</div>
                )}
              </div>

              <div className="new-cover-options">
                <h3>Choose a New Cover</h3>
                {isFetchingCovers ? (
                  <div className="cover-loading-spinner gothic-spinner-content">🕯️ Scrying for Covers...</div>
                ) : covers.length > 0 ? (
                  <div className="cover-thumbnails">
                    {covers.map((url, i) => (
                      <img
                        key={i}
                        src={url}
                        alt="New Cover Option"
                        className="thumbnail"
                        onClick={() => selectNewCover(book, url)}
                      />
                    ))}
                  </div>
                ) : (
                  <p style={{ color: '#aaa', fontStyle: 'italic' }}>🕯️ No covers found for this one.</p>
                )}
              </div>

              <div className="cover-review-buttons">
                <button onClick={() => keepCurrentCover(book)}>🛡️ Keep Current</button>
                <button onClick={() => refetchCovers(book)}>🔄 Refetch Covers</button>
                <button onClick={() => skipBook(book)}>⏭️ Skip</button>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // Reset batch size when resuming a session (optional, for safety)
  (() => {
    setReviewBatchSize(20);
  }, []);

  return (
    <>
      {isImporting && (
        <div className="gothic-spinner-overlay">
          <div className="gothic-spinner-content">
             Summoning Your Books...
          </div>
        </div>
      )}
      <Router>
      {/* 🛑 Full Page Wrapper: Wrapping the whole app and telling it to center itself like a queen */}
      <div
        className="app-wrapper"
        style={{
          width: '100%',        // ← use 100% so we don’t include the scrollbar
          boxSizing: 'border-box'
        }}
      >
        <nav className="main-nav">
  <ul>
    <li><Link to="/home">Home</Link></li> {/* <-- THIS FIXES IT */}
    <li><Link to="/">My Libraries</Link></li>
    <li><Link to="/bookshelf">My Bookshelf</Link></li>
    <li><Link to="/yearly-wrapup">My Yearly Wrapup</Link></li>
    <li><Link to="/dnf">DNF</Link></li>
  </ul>
  <div style={{ position: 'absolute', top: '1rem', right: '1rem' }}>
    <button
      onClick={() => setShowSettingsModal(true)}
      style={{
        background: 'none',
        border: 'none',
        fontSize: '1.5rem',
        color: '#ccc',
        cursor: 'pointer'
      }}
      title="Settings"
    >
      ⚙️
    </button>
  </div>
</nav>
        <div className="page-banner">
          <h1 className="page-banner-text">Page Turning &amp; Soul Burning</h1>
        </div>
        {/* 🛑 Background Image that Actually Grows with the Page */}
        <div
          className="background"
          style={{
            backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${import.meta.env.BASE_URL}newbg.webp)`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundAttachment: 'fixed',
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            width: '100%',
            height: '100%',
            zIndex: -2
          }}
        ></div>
        {/* 🛑 Actual Main Container for All The Book Content */}
        <div className="app-container">
        <Routes>

        {/* 🏠 Libraries Page (the Home / Landing page) */}
        <Route
          path="/"
          element={
            <>
              {showModal && (
                <div className="modal-overlay">
                  <div className="modal-backdrop" onClick={() => setShowModal(false)}>
                    <div
                      className="modal-content"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {/* 🛑 X Button to GTFO */}
                      <button className="close-button" onClick={() => setShowModal(false)}>✖</button>
                      <form onSubmit={handleSubmit} className="add-book-form">
                        {/* 🛑 Title and Author Fields Side-by-Side */}
                        <div className="form-row title-author-row" style={{ position: 'relative' }}>
                          <input
                            type="text"
                            name="title"
                            placeholder="Title"
                            value={newBook.title}
                            onChange={handleChange}
                            required
                            className="form-control"
                          />
                          <input
                            type="text"
                            name="author"
                            placeholder="Author"
                            value={newBook.author}
                            onChange={handleChange}
                            className="form-control"
                          />
                          {/* Search Dropdown UI */}
                          {showSearchDropdown && searchResults.length > 0 && (
                            <div
                              className="search-dropdown"
                              style={{
                                position: 'absolute',
                                top: '100%',
                                left: 0,
                                width: '100%',
                                maxHeight: '200px',
                                overflowY: 'auto',
                                background: '#1e1e1e',
                                border: '1px solid #444',
                                borderRadius: '6px',
                                zIndex: 1000,
                                marginTop: '0.25rem',
                                boxShadow: '0 4px 8px rgba(0,0,0,0.5)',
                              }}
                            >
                              {searchResults.map((book, i) => (
                                <div
                                  key={i}
                                  className="search-result"
                                  onClick={() => {
                                    setNewBook({
                                      ...newBook,
                                      title: book.title,
                                      author: book.author,
                                      cover: book.cover,
                                      series: book.series || 'Standalone',
                                      book_number: book.book_number || '',
                                    });
                                    // Dynamically add new series to dropdown options if not present
                                    if (book.series && !seriesOptions.includes(book.series)) {
                                      setSeriesOptions(prev => [...prev, book.series]);
                                    }
                                    setShowSearchDropdown(false);
                                    setSearchResults([]);
                                  }}
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    padding: '0.5rem',
                                    cursor: 'pointer',
                                    borderBottom: '1px solid #333',
                                    background: 'transparent',
                                    color: '#ddd'
                                  }}
                                >
                                  {book.cover && (
                                    <img
                                      src={book.cover}
                                      alt="cover"
                                      style={{
                                        width: '40px',
                                        height: '60px',
                                        objectFit: 'cover',
                                        marginRight: '10px',
                                        borderRadius: '4px',
                                        boxShadow: '0 2px 6px rgba(0,0,0,0.4)'
                                      }}
                                    />
                                  )}
                                  <span>
  {book.title}
  {book.book_number ? ` (Book ${book.book_number})` : ''} by {book.author}
</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        <div className="form-row series-number-date-row">
                          {newBook.series !== '__new' ? (
                            // 🛑 Series Dropdown if not adding a new series
                            <select
                              name="series"
                              value={newBook.series}
                              onChange={handleChange}
                              className="form-control"
                            >
                          {seriesOptions.sort((a, b) => a.localeCompare(b)).map((option, index) => (
                                <option key={index} value={option}>
                                  {option}
                                </option>
                              ))}
                              <option value="__new">➕ Add New Series...</option>
                            </select>
                          ) : (
                            // 🛑 Text Input for New Series if they choose to add one
                            <>
                              <input
                                className="new-series-input"
                                type="text"
                                placeholder="Enter series name"
                                value={newSeriesName}
                                onChange={(e) => setNewSeriesName(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    const updatedSeries = newSeriesName.trim();
                                    if (updatedSeries) {
                                      const updatedOptions = new Set([...seriesOptions, updatedSeries]);
                                      setSeriesOptions(Array.from(updatedOptions));
                                      setNewBook((prev) => ({ ...prev, series: updatedSeries }));
                                      setNewSeriesName('');
                                    }
                                  }
                                }}
                                required
                              />
                            </>
                          )}

                          {/* 🛑 Book Number Input */}
                          <input
                            type="number"
                            name="book_number"
                            placeholder="Book #"
                            value={newBook.book_number}
                            onChange={handleChange}
                            className="form-control"
                          />

                          {/* 🛑 Date Read Picker */}
                          <input
                            type="date"
                            name="date_read"
                            placeholder="MM/DD/YYYY"
                            value={newBook.date_read}
                            onChange={handleChange}
                            className="form-control"
                          />
                        </div>

                        {/* 🛑 Drag & Drop Cover Upload */}
                        <div
                          className="cover-upload"
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => {
                            e.preventDefault();
                            const file = e.dataTransfer.files[0];
                            const formData = new FormData();
                            formData.append('file', file);
                            fetch('http://localhost:5001/upload_cover', { method: 'POST', body: formData })
                              .then((res) => res.json())
                              .then(({ cover_url }) => {
                                setNewBook((prev) => ({ ...prev, cover: cover_url }));
                              });
                          }}
                          style={{
                            border: '2px dashed #ccc',
                            padding: '1rem',
                            marginBottom: '1rem',
                            textAlign: 'center'
                          }}
                        >
                          {newBook.cover
                            ? <img src={newBook.cover} alt="Cover" style={{ maxWidth: '100%' }} />
                            : 'Drag & drop a cover image here'}
                        </div>

                        {/* 🛑 Star Rating Buttons */}
                        <div className="star-rating">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              className={`star ${star <= (hoverRating || newBook.rating) ? 'selected' : ''}`}
                              onClick={() => handleStarClick(star)}
                              onMouseEnter={() => setHoverRating(star)}
                              onMouseLeave={() => setHoverRating(0)}
                              aria-label={`${star} star`}
                            >
                              <span className="star-icon">★</span>
                            </button>
                          ))}
                        </div>

                        {/* 🛑 Submit Button (Add or Update) */}
                        <button type="submit">{editId ? "Update Book" : "Add Book"}</button>
                      </form>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Settings Modal */}
              {showSettingsModal && (
                <div className="modal-overlay">
                  <div className="modal-backdrop" onClick={() => setShowSettingsModal(false)}>
                    <div style={{ marginTop: '3rem' }}>
                    <div
                      className="modal-content"
                      onClick={(e) => e.stopPropagation()}
                        style={{ maxWidth: '400px', padding: '2rem', textAlign: 'center', position: 'relative' }}
                    >
                        <button
                          onClick={() => setShowSettingsModal(false)}
                          style={{
                            position: 'absolute',
                            top: '1rem',
                            right: '1rem',
                            background: 'none',
                            border: 'none',
                            fontSize: '1.5rem',
                            color: '#fff',
                            textShadow: '0 0 4px #000',
                            cursor: 'pointer'
                          }}
                          title="Close"
                        >
                          ✖️
                        </button>
                      <h2 style={{ marginBottom: '1rem', color: '#ff9966' }}>⚙️ Settings</h2>

                      {/* Goodreads Import */}
                      <label htmlFor="import-csv" style={{ display: 'block', marginBottom: '1rem', cursor: 'pointer' }}>
                        <img src="/Goodreads.png" alt="Goodreads Import" style={{ width: '32px', height: '32px', marginBottom: '0.5rem' }} />
                        <div style={{ fontSize: '0.9rem', color: '#ccc' }}>Import Goodreads CSV</div>
                        <input
                          id="import-csv"
                          type="file"
                          accept=".csv"
                          onChange={(e) => {
                            importGoodreadsCSV(e.target.files[0]);
                            setShowSettingsModal(false);
                          }}
                          style={{ display: 'none' }}
                        />
                      </label>

                        {/* Settings Modal buttons layout update */}
                        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginBottom: '1rem' }}>
                          {/* Review Covers */}
                      <button
                        onClick={() => {
                              fetch('http://localhost:5001/books/pending-review')
                                .then(res => res.json())
                                .then(data => {
                                  if (data.length) {
                                    setPendingCoverFixes(data);
                                    localStorage.setItem('pendingCoverFixes', JSON.stringify(data));
                                    setReviewBatchSize(20);
                                    setIsReviewingCovers(true);
                                    data.slice(0, 20).forEach(book => fetchNewCovers(book));
                                } else {
                                    alert("🎉 All books already have covers!");
                                }
                              })
                                .catch((err) => console.error("Failed to fetch books needing review:", err));
                              setShowSettingsModal(false);
                        }}
                        style={{
                              backgroundColor: '#333',
                          color: '#fff',
                          padding: '0.5rem 1rem',
                          border: 'none',
                          borderRadius: '4px',
                          fontWeight: 'bold',
                          cursor: 'pointer'
                        }}
                      >
                        🗑️ Delete ALL Books
                      </button>

                      {/* Manage Series */}
                      <button
                        onClick={() => {
                          setShowSeriesManager(true);
                          setShowSettingsModal(false);
                        }}
                        style={{
                          backgroundColor: '#444',
                          color: '#fff',
                          padding: '0.5rem 1rem',
                          border: 'none',
                          borderRadius: '4px',
                          marginTop: '1rem',
                          cursor: 'pointer'
                        }}
                      >
                        📖 Manage Series
                      </button>
                        </div>
                        {/* Delete All Books below the flex container */}
                        <button
                          onClick={() => {
                            if (window.confirm("⚠️ Are you sure? This will delete ALL books. This action cannot be undone.")) {
                              fetch('http://localhost:5001/api/books', { method: 'DELETE' })
                                .then((res) => {
                                  if (res.ok) {
                                    setBooks([]);
                                    setPendingCoverFixes([]);
                                    localStorage.setItem('pendingCoverFixes', JSON.stringify([]));
                                    setIsReviewingCovers(false);
                                    alert("✅ All books deleted successfully.");
                                  } else {
                                    console.error("Failed to mass delete books.");
                                  }
                                })
                                .catch((err) => console.error("Mass delete failed:", err));
                            }
                          }}
                          style={{
                            margin: '1rem 0',
                            backgroundColor: '#500',
                            color: '#fff',
                            padding: '0.5rem 1rem',
                            border: 'none',
                            borderRadius: '4px',
                            fontWeight: 'bold',
                            cursor: 'pointer'
                          }}
                        >
                          🗑️ Delete ALL Books
                        </button>
                        {/* No bottom "✖ Close" button here, per instructions */}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Series Manager Modal */}
              {showSeriesManager && (
                <div className="modal-overlay">
                  <div className="modal-backdrop" onClick={() => setShowSeriesManager(false)}>
                    <div
                      className="modal-content"
                      onClick={(e) => e.stopPropagation()}
                      style={{ maxWidth: '400px', padding: '2rem', textAlign: 'center', maxHeight: '70vh', overflowY: 'auto' }}
                    >
                      <button
                        onClick={() => setShowSeriesManager(false)}
                        style={{
                          position: 'absolute',
                          top: '1rem',
                          right: '1rem',
                          background: 'none',
                          border: 'none',
                          fontSize: '1.5rem',
                          color: '#fff',
                          textShadow: '0 0 4px #000',
                          cursor: 'pointer'
                        }}
                        title="Close"
                      >
                        ✖️
                      </button>
                      <h2 style={{ marginBottom: '1rem', color: '#ff9966' }}>📖 Manage Series</h2>
                      {/* List series with delete options and inline editing */}
                      <div className="series-list" style={{ marginBottom: '1rem', maxHeight: '45vh', overflowY: 'auto', padding: '0.5rem', background: 'rgba(0,0,0,0.3)', borderRadius: '6px' }}>
                        {seriesOptions.sort().map((series, i) => (
                          <div
                            key={i}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              marginBottom: '0.3rem',
                              gap: '0.5rem',
                              background: 'rgba(255,255,255,0.05)',
                              padding: '0.3rem 0.5rem',
                              borderRadius: '4px',
                              border: '1px solid rgba(255,255,255,0.1)'
                            }}
                          >
                            <input
                              type="text"
                              value={series}
                              onChange={(e) => {
                                const updatedSeries = [...seriesOptions];
                                updatedSeries[i] = e.target.value;
                                setSeriesOptions(updatedSeries);
                              }}
                              style={{
                                flexGrow: 1,
                                padding: '0.4rem',
                                borderRadius: '4px',
                                border: '1px solid #666',
                                backgroundColor: 'rgba(255,255,255,0.15)',
                                color: '#fff'
                              }}
                              disabled={series === 'Standalone'}
                            />
                            {series !== 'Standalone' && (
                              <button
                                onClick={() => {
                                  const updated = seriesOptions.filter(s => s !== series);
                                  setSeriesOptions(updated);
                                }}
                                style={{
                                  background: 'none',
                                  border: 'none',
                                  color: 'red',
                                  fontSize: '1.2rem',
                                  cursor: 'pointer'
                                }}
                              >
                                ✖
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                      {/* Add new series manually */}
                      <input
                        type="text"
                        placeholder="New series name"
                        value={newSeriesName}
                        onChange={(e) => setNewSeriesName(e.target.value)}
                        style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', borderRadius: '4px' }}
                      />
                      <button
                        onClick={() => {
                          if (newSeriesName.trim()) {
                            const updated = new Set([...seriesOptions, newSeriesName.trim()]);
                            setSeriesOptions(Array.from(updated));
                            setNewSeriesName('');
                          }
                        }}
                        style={{
                          backgroundColor: '#444',
                          color: '#fff',
                          padding: '0.5rem 1rem',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        ➕ Add Series
                      </button>
                      {/* Save Changes button */}
                      <button
                        onClick={() => {
                          // NEW LOGIC: robust rename/delete mapping for series (improved per request)
                          const updatedSeriesMap = {};

                          const originalSet = new Set(originalSeriesOptions.map(s => s.trim().toLowerCase()));
                          const currentSet = new Set(seriesOptions.map(s => s.trim().toLowerCase()));

                          originalSeriesOptions.forEach(original => {
                            const originalNormalized = original.trim().toLowerCase();

                            if (!currentSet.has(originalNormalized)) {
                              const newlyAddedSeries = seriesOptions.find(s =>
                                !originalSet.has(s.trim().toLowerCase())
                              );

                              if (newlyAddedSeries) {
                                updatedSeriesMap[original] = newlyAddedSeries.trim();
                              } else {
                                updatedSeriesMap[original] = 'Standalone';
                              }
                            }
                          });

                          fetch('http://localhost:5001/api/series', {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ updates: updatedSeriesMap })
                          })
                            .then(res => {
                              if (!res.ok) throw new Error('Failed to update series');
                              return res.json();
                            })
                            .then(() => {
                              return fetchBooks(); // REFETCH the books to properly rebuild seriesOptions
                            })
                            .then(() => {
                              setOriginalSeriesOptions([...seriesOptions]);
                              setShowSeriesManager(false); // Close modal after successful refresh
                              alert('✅ Series changes saved and synced!');
                            })
                            .catch(err => console.error('Series update failed:', err));
                        }}
                        style={{
                          backgroundColor: '#2d2d2d',
                          color: '#fff',
                          padding: '0.5rem 1rem',
                          border: 'none',
                          borderRadius: '6px',
                          marginTop: '1rem',
                          cursor: 'pointer',
                          fontSize: '1rem',
                          fontWeight: 'bold'
                        }}
                      >
                        💾 Save Changes
                      </button>
                      {/* Close */}
                      <div>
                        <button
                          onClick={() => setShowSeriesManager(false)}
                          style={{
                            marginTop: '2rem',
                            background: 'none',
                            color: '#ccc',
                            border: 'none',
                            fontSize: '1.2rem',
                            cursor: 'pointer'
                          }}
                        >
                          ✖ Close
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 🛑 Button to Open the Modal */}
              <button
  className="open-modal-button"
  onClick={() => {
    setNewBook({
      title: '',
      author: '',
      series: '',
      book_number: '',
      date_read: '',
      rating: 0,
      cover: ''
    });
    setNewSeriesName('');
    setSearchResults([]);
    setShowSearchDropdown(false);
    setShowModal(true);
  }}
>
                ➕ Add New Book
              </button>


              {/* 🛑 Sort Dropdown */}
              <div style={{ margin: '1rem 0', textAlign: 'center' }}>
                <label>
                  Sort by: {' '}
                  <select value={sortOption} onChange={(e) => setSortOption(e.target.value)}>
                    <option value="title">Title</option>
                    <option value="author">Author</option>
                    <option value="series">Series</option>
                  </select>
                </label>
              </div>

            {/* Page Navigation Buttons for Book Grid */}
            <div className="pagination">
                {Array.from({ length: totalPages }, (_, index) => (
                  <button
                    key={index}
                    onClick={() => handlePageChange(index + 1)}
                    className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                    >
                    {index + 1}
                    </button>
                ))}
              </div>

              {/* 🛑 Book Grid Display */}
              {books.length === 0 ? (
                <p>No books yet...</p>
              ) : (
                <div className="book-grid">
                  {currentBooks.map((book) => (
                    editId === book.id ? (
                      // 🛑 Inline Edit Card: Updated structure for consistency and polish
                      <div className="book-card">
                        <div
                          className="cover-upload"
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => {
                            e.preventDefault();
                            const file = e.dataTransfer.files[0];
                            const formData = new FormData();
                            formData.append('file', file);
                            fetch('http://localhost:5001/upload_cover', { method: 'POST', body: formData })
                              .then((res) => res.json())
                              .then(({ cover_url }) => {
                                setInlineEditBook((prev) => ({ ...prev, cover: cover_url }));
                              });
                          }}
                          style={{
                            border: '2px dashed #ccc',
                            padding: '0.5rem',
                            marginBottom: '0.5rem',
                            textAlign: 'center',
                            minHeight: '160px',
                            maxHeight: '180px',
                            position: 'relative'
                          }}
                        >
                          {inlineEditBook.cover
                            ? (
                              <>
                                <img src={inlineEditBook.cover} alt="Cover" style={{ maxWidth: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center' }} />
                                {inlineEditBook.cover && (
                                  <button
                                    type="button"
                                    className="remove-cover-button"
                                    onClick={() => setInlineEditBook((b) => ({ ...b, cover: '' }))}
                                    style={{
                                      position: 'absolute',
                                      top: '4px',
                                      right: '4px',
                                      background: 'rgba(255,255,255,0.8)',
                                      border: 'none',
                                      borderRadius: '50%',
                                      cursor: 'pointer',
                                      padding: '0.15em 0.45em',
                                      fontSize: '1rem',
                                      lineHeight: 1
                                    }}
                                  >
                                    ✖️
                                  </button>
                                )}
                              </>
                            )
                            : 'Drag & drop a new cover image here'}
                        </div>
                        <input
                          type="text"
                          value={inlineEditBook.title}
                          onChange={(e) => setInlineEditBook((b) => ({ ...b, title: e.target.value }))}
                          className="form-control"
                          placeholder="Title"
                          style={{ marginBottom: '0.5rem' }}
                        />
                        <input
                          type="text"
                          value={inlineEditBook.author}
                          onChange={(e) => setInlineEditBook((b) => ({ ...b, author: e.target.value }))}
                          className="form-control"
                          placeholder="Author"
                          style={{ marginBottom: '0.5rem' }}
                        />
                        <select
                          value={inlineEditBook.series}
                          onChange={(e) => setInlineEditBook((b) => ({ ...b, series: e.target.value }))}
                          className="form-control"
                          style={{
                            marginBottom: '0.5rem',
                            fontSize: '0.85rem',
                            padding: '0.5rem 0.75rem',
                            height: '2.2rem'
                          }}
                        >
                          {seriesOptions.sort((a, b) => a.localeCompare(b)).map((opt, i) => (
                            <option key={i} value={opt}>{opt}</option>
                          ))}
                        </select>
                        <input
                          type="number"
                          value={inlineEditBook.book_number}
                          onChange={(e) => setInlineEditBook((b) => ({ ...b, book_number: e.target.value }))}
                          className="form-control"
                          placeholder="Book #"
                          style={{
                            marginBottom: '0.5rem',
                            padding: '0.25rem',
                            width: '60px',
                            fontSize: '0.85rem'
                          }}
                        />
                        <input
                          type="date"
                          value={inlineEditBook.date_read || ''}
                          onChange={(e) => setInlineEditBook((b) => ({ ...b, date_read: e.target.value }))}
                          className="form-control"
                          placeholder="Date Read"
                          style={{
                            marginBottom: '0.5rem',
                            fontSize: '1rem',
                            padding: '0.5rem',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)'
                          }}
                        />
                        <div
                          className="star-rating"
                          style={{
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            padding: '0.5rem 0',
                            gap: '0.2rem',
                            marginBottom: '0.5rem'
                          }}
                        >
                          {[1, 2, 3, 4, 5].map((s) => (
                            <button
                              key={s}
                              type="button"
                              className={`star ${s <= inlineEditBook.rating ? 'selected' : ''}`}
                              onClick={() => setInlineEditBook((b) => ({ ...b, rating: s }))}
                              style={{
                                background: 'none',
                                border: 'none',
                                padding: '0',
                                fontSize: '1.2rem'
                              }}
                            >
                              <span className="star-icon">★</span>
                            </button>
                          ))}
                        </div>
                        <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
                          <button
                            type="button"
                            onClick={saveInline}
                            style={{
                              background: 'none',
                              border: '1px solid #ccc',
                              padding: '0.25rem 0.5rem',
                              color: 'var(--glow-gold)'
                            }}
                          >
                            ✅ Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditId(null)}
                            style={{
                              background: 'none',
                              border: '1px solid #ccc',
                              padding: '0.25rem 0.5rem',
                              color: 'var(--glow-gold)'
                            }}
                          >
                            ❌ Cancel
                          </button>
                        </div>
                        {/* Restore Edit and Delete buttons for consistency */}
                        <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
                          <button
                            type="button"
                            onClick={() => startEdit(book)}
                            style={{ cursor: 'pointer', background: 'none', border: 'none' }}
                          >
                            ✏️
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteBook(book.id)}
                            style={{ cursor: 'pointer', background: 'none', border: 'none' }}
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    ) : (
                      // 🛑 Regular Book Card: This is what everyone else sees (no editing here, just vibes)
                      <div key={book.id} className="book-card">
                        {/* 📚 Book Cover: Not editable here, just eye candy. */}
                        {book.cover ? (
                        <img
  src={
    book.cover
      ? book.cover.startsWith('http')
        ? book.cover
        : `http://localhost:5001${book.cover}`
      : 'fallback-image.jpg' // optional fallback if you want
  }
  alt="Cover"
  style={{
    maxWidth: '100%',
    height: '180px',
    objectFit: 'contain',
    marginBottom: '0.5rem',
    borderRadius: '8px'
  }}
/>
                        ) : (
                          // 📦 Placeholder if no cover. Sorry, not every book gets a face.
                          <div
                            className="image-placeholder"
                            style={{
                              width: '100%',
                              height: '180px',
                              backgroundColor: 'rgba(0,0,0,0.05)',
                              borderRadius: '8px',
                              marginBottom: '0.5rem'
                            }}
                          />
                        )}
                        {/* 📖 Card Content: All the juicy details, but you can't edit them here */}
                        <div className="card-content">
                          {/* 🔒 Title: For reading only, not for changing here. */}
                          <h2 className="book-title">{book.title}</h2>
                          {/* 🔒 Author: Just showing off, not editable. */}
                          <p className="author-name">{book.author}</p>
                          {/* 🔒 Date Read: Display when it was read */}
                          {/* 🔒 Series: Show series and book number if not Standalone */}
                          {seriesOptions.includes(book.series) && book.series !== 'Standalone' && (
                            <p className="series-info">
                              {book.series} {book.book_number && `(#${book.book_number})`}
                            </p>
                          )}
                          {book.date_read && (
                            <p className="date-read">
                              📅 {new Date(new Date(book.date_read).getTime() + 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                            </p>
                          )}
                          {/* ⭐ Static Star Rating: Just for flexing, can't change here. */}
                          <div className="rating">
                            {'⭐'.repeat(book.rating)}
                          </div>
                        </div>
                        {/* 🛠️ Action Buttons: Edit or yeet this book */}
                        <div style={{ marginTop: '0.5rem' }}>
                          {/* ✏️ Edit Button: Click to unlock the chaos of inline editing. */}
                          <button
                            type="button"
                            onClick={() => startEdit(book)}
                            style={{ cursor: 'pointer', marginRight: '0.5rem', background: 'none', border: 'none' }}
                          >
                            ✏️
                          </button>
                          {/* 🗑️ Delete Button: Click to send this book to the shadow realm (forever). */}
                          <button
                            type="button"
                            onClick={() => deleteBook(book.id)}
                            style={{ cursor: 'pointer', background: 'none', border: 'none' }}
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    )
                  ))}
                </div>
              )}
              {/* Duplicate Pagination at Bottom */}
              <div className="pagination" style={{ marginTop: '1rem' }}>
                {Array.from({ length: totalPages }, (_, index) => (
                  <button
                    key={`bottom-${index}`}
                    onClick={() => handlePageChange(index + 1)}
                    className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                  >
                    {index + 1}
                  </button>
                ))}
              </div>
            {/* 🛑 End of Main Container */}
            </>
          }
        />

      

{/* 📚 Other Pages */}
<Route path="/home" element={<HomePage />} />
<Route path="/bookshelf" element={<BookshelfPage />} />
<Route path="/yearly-wrapup" element={<YearlyWrapUpPage />} />
<Route path="/dnf" element={<DnfPage />} />
{/* 🛑 End of Other Pages */}
</Routes>

</div> {/* End of .app-container */}
</div> {/* End of .app-wrapper */}
      </Router>
    </>
  ); // <-- CLOSE THE FUNCTION NICELY HERE
}

export default App;

// 🛑 End of App.jsx